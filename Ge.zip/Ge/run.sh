#!/bin/bash

mpirun -np 6 siesta <silicon-relax.fdf>silicon-relax.fdf.sout   # relaxation

mpirun -np 6 siesta <silicon-dos.fdf>silicon-dos.fdf.sout  # DOS and Band structure calculations

gnubands < silicon.bands > band.dat   # Post-processing of the bandstructure

gnuplot Band.gnu  
gnuplot Band+Dos.gnu   # plot the bandstructure
