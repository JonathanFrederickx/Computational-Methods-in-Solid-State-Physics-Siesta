#!/bin/bash

mpirun -np 6 siesta <iron-relax.fdf>iron-relax.fdf.sout   # relaxation

mpirun -np 6 siesta <iron-dos.fdf>iron-dos.fdf.sout  # DOS and Band structure calculations

gnubands < iron.bands > band.dat   # Post-processing of the bandstructure

gnuplot Band.gnu  
gnuplot Band+Dos.gnu   # plot the bandstructure
