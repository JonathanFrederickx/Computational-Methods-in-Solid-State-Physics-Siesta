#!/bin/bash

mpirun -np 6 siesta <copper-relax.fdf>copper-relax.fdf.sout   # relaxation

mpirun -np 6 siesta <copper-dos.fdf>copper-dos.fdf.sout  # DOS and Band structure calculations

gnubands < copper.bands > band.dat   # Post-processing of the bandstructure

gnuplot Band.gnu  
gnuplot Band+Dos.gnu   # plot the bandstructure
